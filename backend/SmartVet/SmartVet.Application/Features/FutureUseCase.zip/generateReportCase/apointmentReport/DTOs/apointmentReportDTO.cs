﻿using ConectaFapes.Common.Application.DTO;

namespace SmartVet.Application.Features.generateReportCase.apointmentReport.DTOs
{
    public class apointmentReportDto : BaseDto
    {
        public apointmentReportDto()
        {

        }
    }
}
