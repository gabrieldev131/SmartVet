﻿using ConectaFapes.Common.Application.DTO;

namespace SmartVet.Application.Features.generateReportCase.userReport.DTOs
{
    public class userReportDto : BaseDto
    {
        public userReportDto()
        {

        }
    }
}
