using FluentValidation;

namespace SmartVet.Application.Features.CRUD.VeterinarianEntity.VeterinarianCase.Update
{
    public class UpdateVeterinarianValidator : AbstractValidator<UpdateVeterinarianCommand>
    {
        public UpdateVeterinarianValidator()
        {

        }
    }
}