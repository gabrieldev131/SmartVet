using FluentValidation;

namespace SmartVet.Application.Features.CRUD.VeterinarianEntity.VeterinarianCase.Delete
{
    public class DeleteVeterinarianValidator : AbstractValidator<DeleteVeterinarianCommand>
    {
        public DeleteVeterinarianValidator()
        {

        }
    }
}