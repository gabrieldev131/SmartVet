using FluentValidation;

namespace SmartVet.Application.Features.CRUD.VeterinarianEntity.VeterinarianCase.GetById
{
    public class GetByIdVeterinarianValidator : AbstractValidator<GetByIdVeterinarianCommand>
    {
        public GetByIdVeterinarianValidator()
        {

        }
    }
}