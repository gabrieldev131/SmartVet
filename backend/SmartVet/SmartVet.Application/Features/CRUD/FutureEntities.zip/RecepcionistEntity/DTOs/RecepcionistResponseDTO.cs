using SmartVet.Application.Dto;


namespace SmartVet.Application.Features.CRUD.RecepcionistEntity.DTOs
{
    public class RecepcionistResponseDTO : BaseDto
    {



    }
}
