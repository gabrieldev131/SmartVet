using FluentValidation;

namespace SmartVet.Application.Features.CRUD.RecepcionistEntity.RecepcionistCase.GetAll
{
    public class GetAllRecepcionistValidator : AbstractValidator<GetAllRecepcionistCommand>
    {
        public GetAllRecepcionistValidator()
        {
        }
    }
}