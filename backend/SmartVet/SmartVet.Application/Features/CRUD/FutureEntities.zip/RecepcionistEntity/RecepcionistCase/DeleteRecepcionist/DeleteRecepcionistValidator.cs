using FluentValidation;

namespace SmartVet.Application.Features.CRUD.RecepcionistEntity.RecepcionistCase.Delete
{
    public class DeleteRecepcionistValidator : AbstractValidator<DeleteRecepcionistCommand>
    {
        public DeleteRecepcionistValidator()
        {

        }
    }
}