using FluentValidation;

namespace SmartVet.Application.Features.CRUD.RecepcionistEntity.RecepcionistCase.Create
{
    public class CreateRecepcionistValidator : AbstractValidator<CreateRecepcionistCommand>
    {
        public CreateRecepcionistValidator()
        {
        }
    }
}