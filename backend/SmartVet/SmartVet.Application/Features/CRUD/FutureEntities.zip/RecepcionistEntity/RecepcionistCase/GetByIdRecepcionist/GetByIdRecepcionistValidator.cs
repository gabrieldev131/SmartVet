using FluentValidation;

namespace SmartVet.Application.Features.CRUD.RecepcionistEntity.RecepcionistCase.GetById
{
    public class GetByIdRecepcionistValidator : AbstractValidator<GetByIdRecepcionistCommand>
    {
        public GetByIdRecepcionistValidator()
        {

        }
    }
}