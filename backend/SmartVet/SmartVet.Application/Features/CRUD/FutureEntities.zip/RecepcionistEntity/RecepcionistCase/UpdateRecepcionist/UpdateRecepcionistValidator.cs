using FluentValidation;

namespace SmartVet.Application.Features.CRUD.RecepcionistEntity.RecepcionistCase.Update
{
    public class UpdateRecepcionistValidator : AbstractValidator<UpdateRecepcionistCommand>
    {
        public UpdateRecepcionistValidator()
        {

        }
    }
}