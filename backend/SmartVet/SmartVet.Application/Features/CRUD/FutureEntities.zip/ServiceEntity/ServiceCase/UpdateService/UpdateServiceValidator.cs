using FluentValidation;

namespace SmartVet.Application.Features.CRUD.ServiceEntity.ServiceCase.Update
{
    public class UpdateServiceValidator : AbstractValidator<UpdateServiceCommand>
    {
        public UpdateServiceValidator()
        {

        }
    }
}