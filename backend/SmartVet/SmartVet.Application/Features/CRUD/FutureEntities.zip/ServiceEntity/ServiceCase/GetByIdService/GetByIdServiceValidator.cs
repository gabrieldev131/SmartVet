using FluentValidation;

namespace SmartVet.Application.Features.CRUD.ServiceEntity.ServiceCase.GetById
{
    public class GetByIdServiceValidator : AbstractValidator<GetByIdServiceCommand>
    {
        public GetByIdServiceValidator()
        {

        }
    }
}