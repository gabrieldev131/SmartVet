using FluentValidation;

namespace SmartVet.Application.Features.CRUD.AdminEntity.AdminCase.Update
{
    public class UpdateAdminValidator : AbstractValidator<UpdateAdminCommand>
    {
        public UpdateAdminValidator()
        {

        }
    }
}