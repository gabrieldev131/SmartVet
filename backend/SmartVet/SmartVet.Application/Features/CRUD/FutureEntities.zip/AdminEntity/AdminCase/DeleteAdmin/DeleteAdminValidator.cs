using FluentValidation;

namespace SmartVet.Application.Features.CRUD.AdminEntity.AdminCase.Delete
{
    public class DeleteAdminValidator : AbstractValidator<DeleteAdminCommand>
    {
        public DeleteAdminValidator()
        {

        }
    }
}