using FluentValidation;

namespace SmartVet.Application.Features.CRUD.AdminEntity.AdminCase.GetById
{
    public class GetByIdAdminValidator : AbstractValidator<GetByIdAdminCommand>
    {
        public GetByIdAdminValidator()
        {

        }
    }
}