using SmartVet.Application.Dto;


namespace SmartVet.Application.Features.CRUD.AdminEntity.DTOs
{
    public class AdminResponseDTO : BaseDto
    {



    }
}
