using FluentValidation;

namespace SmartVet.Application.Features.CRUD.ClientEntity.ClientCase.GetById
{
    public class GetByIdClientValidator : AbstractValidator<GetByIdClientCommand>
    {
        public GetByIdClientValidator()
        {

        }
    }
}